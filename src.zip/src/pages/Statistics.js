import React, { useEffect, useState } from "react";
import coursePrefixes from "../data/coursePrefixes.json";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import { Form, Button } from "react-bootstrap";
import majors from "../data/majors.json";
import { auth } from "../firebase";
import "../styles/global.css";
import "../styles/Statistics.css";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const COURSE_PREFIXES = coursePrefixes;

const API_URL =
  process.env.NODE_ENV === "production"
    ? process.env.REACT_APP_API_URL
    : process.env.REACT_APP_BACKEND_URL;

function Statistics() {
  const [major, setMajor] = useState("");
  const [availableMajors, setAvailableMajors] = useState([]);
  const [semesterData, setSemesterData] = useState({});
  const [statType, setStatType] = useState("distribution");
  const [selectedPrefixes, setSelectedPrefixes] = useState([]);
  const [showPrefixFilter, setShowPrefixFilter] = useState(false);
  const [showTop10, setShowTop10] = useState(false);

  useEffect(() => {
    setAvailableMajors(majors.map((m) => m.name));
  }, []);

  useEffect(() => {
    const savedMajor = localStorage.getItem("selectedMajor");
    if (savedMajor) {
      setMajor(savedMajor);
    }
  }, []);

  const handleSubmit = async () => {
    if (!major) return;

    try {
      const idToken = await auth.currentUser.getIdToken();

      const res = await fetch(
        `${API_URL}/statistics/${major}?type=${statType}`,
        {
          headers: {
            Authorization: `Bearer ${idToken}`,
          },
        }
      );

      const text = await res.text();
      const data = JSON.parse(text);
      setSemesterData(data);
    } catch (err) {
      console.error("Error fetching statistics:", err);
    }
  };

  return (
    <div className="container mt-5 text-center">
      <h1>Statistics by Major</h1>

      <Form.Select
        className="my-4 w-50 mx-auto"
        value={major}
        onChange={(e) => {
          const selected = e.target.value;
          setMajor(selected);
          localStorage.setItem("selectedMajor", selected);
        }}
      >
        <option value="">Select a Major</option>
        {availableMajors.map((m) => (
          <option key={m} value={m}>
            {m}
          </option>
        ))}
      </Form.Select>

      <Form.Select
        className="my-4 w-50 mx-auto"
        value={statType}
        onChange={(e) => setStatType(e.target.value)}
      >
        <option value="distribution">Course Distribution by Semester</option>
        <option value="grades">Grade Distribution by Course</option>
      </Form.Select>

      <Form.Check
        type="checkbox"
        label="Filter by Course Prefix"
        className="mb-2 text-start w-50 mx-auto"
        checked={showPrefixFilter}
        onChange={(e) => setShowPrefixFilter(e.target.checked)}
      />

      <Form.Check
        type="checkbox"
        label="Show Only Top 10"
        className="mb-2 text-start w-50 mx-auto"
        checked={showTop10}
        onChange={(e) => setShowTop10(e.target.checked)}
      />

      {showPrefixFilter && (
        <Form.Group className="mb-3 text-start w-50 mx-auto">
          <Form.Label>Filter by Course Prefix</Form.Label>
          <div className="prefix-filter-box">
            {COURSE_PREFIXES.map((prefix) => (
              <Form.Check
                key={prefix}
                type="checkbox"
                label={prefix}
                checked={selectedPrefixes.includes(prefix)}
                onChange={(e) => {
                  const updated = e.target.checked
                    ? [...selectedPrefixes, prefix]
                    : selectedPrefixes.filter((p) => p !== prefix);
                  setSelectedPrefixes(updated);
                }}
              />
            ))}
          </div>
        </Form.Group>
      )}

      <Button variant="primary" onClick={handleSubmit} className="mb-4">
        Submit
      </Button>

      {statType === "distribution"
        ? Object.entries(semesterData).map(([semester, courseCounts]) => {
            let filteredEntries = Object.entries(courseCounts).filter(
              ([id]) => {
                const prefix = id
                  .substring(0, id.lastIndexOf(" "))
                  .replace(/[_ ]/g, "")
                  .toUpperCase();
                const normalized = selectedPrefixes.map((p) =>
                  p.replace(/[_ ]/g, "").toUpperCase()
                );
                return (
                  selectedPrefixes.length === 0 || normalized.includes(prefix)
                );
              }
            );

            if (showTop10) {
              filteredEntries = filteredEntries
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10);
            }

            if (filteredEntries.length === 0) return null;

            const labels = filteredEntries.map(([id]) => id);
            const values = filteredEntries.map(([, val]) => val);

            return (
              <div key={semester} className="mb-5">
                <h4>{semester}</h4>
                <div className="chart-container">
                  <Bar
                    data={{
                      labels,
                      datasets: [
                        { data: values, backgroundColor: "#36A2EB" },
                      ],
                    }}
                    options={{
                      responsive: true,
                      plugins: { legend: { display: false } },
                      scales: {
                        x: { title: { display: true, text: "Course" } },
                        y: {
                          title: {
                            display: true,
                            text: "Percentage of Students",
                          },
                          beginAtZero: true,
                          max: 100,
                        },
                      },
                    }}
                  />
                </div>
              </div>
            );
          })
        : Object.entries(semesterData)
            .filter(([courseId]) => {
              const prefix = courseId
                .substring(0, courseId.lastIndexOf(" "))
                .replace(/[_ ]/g, "")
                .toUpperCase();
              const normalized = selectedPrefixes.map((p) =>
                p.replace(/[_ ]/g, "").toUpperCase()
              );
              return (
                selectedPrefixes.length === 0 || normalized.includes(prefix)
              );
            })
            .map(([courseId, gradeCounts]) => {
              const labels = Object.keys(gradeCounts);
              const values = Object.values(gradeCounts);

              return (
                <div key={courseId} className="mb-5">
                  <h4>{courseId}</h4>
                  <div className="chart-container">
                    <Bar
                      data={{
                        labels,
                        datasets: [
                          { data: values, backgroundColor: "#FF6384" },
                        ],
                      }}
                      options={{
                        responsive: true,
                        plugins: { legend: { display: false } },
                        scales: {
                          x: { title: { display: true, text: "Grade" } },
                          y: {
                            title: {
                              display: true,
                              text: "Percentage of Students",
                            },
                            beginAtZero: true,
                            max: 100,
                          },
                        },
                      }}
                    />
                  </div>
                </div>
              );
            })}
    </div>
  );
}

export default Statistics;
